#include <png.h>
#include <sys/types.h>
#include <dirent.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#define ishex(C) (((C)>='0' && (C)<='9') || ((C)>='a' && (C)<='z') || ((C)>='A' && (C)<='Z'))
#define BUFTAM 2048

int tam = 0;
FILE *bmf;

void generarbitmap(FILE *fp, char* _nombre) {
	char nombre[32];
	//uint16_t prueba[17];
	strncpy(nombre, _nombre+3, 32);
	if (strlen(nombre)<4)
		return;
	nombre[strlen(nombre)-4]=0;

	png_structp png_ptr = png_create_read_struct(PNG_LIBPNG_VER_STRING, (png_voidp)NULL, NULL, NULL);
	if (!png_ptr)
		return;

	png_infop info_ptr = png_create_info_struct(png_ptr);
	if (!info_ptr) {
		png_destroy_read_struct(&png_ptr, (png_infopp)NULL, (png_infopp)NULL);
		return;
	}

	png_infop end_info = png_create_info_struct(png_ptr);
	if (!end_info) {
		png_destroy_read_struct(&png_ptr, &info_ptr, (png_infopp)NULL);
		return;
	}
	
	png_set_sig_bytes(png_ptr, 8);
	png_init_io(png_ptr, fp);
	
	png_read_png(png_ptr, info_ptr, PNG_TRANSFORM_STRIP_16 | PNG_TRANSFORM_STRIP_ALPHA | PNG_TRANSFORM_PACKING | PNG_TRANSFORM_GRAY_TO_RGB, NULL);

	// Obtengo información básica
	png_uint_32 width, height, color_type, bit_depth;
	color_type = png_get_color_type(png_ptr, info_ptr);
	bit_depth = png_get_bit_depth(png_ptr, info_ptr);
	width = png_get_image_width(png_ptr, info_ptr);
	height = png_get_image_height(png_ptr, info_ptr);
	
	//printf("El fichero \"%s\" es de %ux%u pixels\n", nombre, (unsigned int)width, (unsigned int)height);
	
	// Empiezo a generar el bitmap
	uint16_t bitmap = 0;
	int pos = 15;
	//int posprueba = 1;
	printf("uint16_t _%s [] = {0x%.2x%.2x", nombre, (unsigned int)height, (unsigned int)width);
	tam+=2;
	
	//prueba[0] = height<<8 | width;
	
	// Obtengo los pixels
	png_bytep *row_pointers = png_get_rows(png_ptr, info_ptr);
	int i,j;
	for (i=0; i<height; i++) {
		for (j=0; j<width; j++) {
			//printf("%c", row_pointers[i][j*3]==0?'#':' ');
			bitmap |= (row_pointers[i][j*3]==0)<<pos;
			pos--;
			if (pos < 0) {
				printf(",0x%.4x", bitmap);
				//prueba[posprueba] = bitmap;
				//posprueba++;
				bitmap = 0;
				pos = 15;
				tam+=2;
			}
		}
		//printf("\n");
	}
	if (pos!=15) {
		printf(",0x%.4x", bitmap);
		tam+=2;
		//prueba[posprueba] = bitmap;
	}
	printf("};\n");
	
/*	pos = 15;
	posprueba = 1;
	for (i=0; i<height; i++) {
		for (j=0; j<width; j++) {
			printf("%c", (prueba[posprueba]&(0x0001<<pos))!=0?'#':' ');
			pos--;
			if (pos < 0) {
				posprueba++;
				pos=15;
			}
		}
		printf("\n");
	}
*/	
	png_destroy_read_struct(&png_ptr, &info_ptr, &end_info);
}

int main() {
	DIR *dp;
	struct dirent *ep;
	unsigned char buffer[BUFTAM];

	if (chdir("letras") == -1) {
		perror("No se puede cambiar al directorio \"letras\"");
		return 1;
	}
	dp = opendir ("./");
	if (!dp) {
		perror("No se puede leerse el directorio \"letras\"");
		return 1;
	}
	
	bmf = fopen("../letras.bmf", "wb");
	if (!bmf) {
		perror("No se puede abir \"letras.bmf\" para escritura");
		return 1;
	}

	while (ep = readdir (dp)) {
		if (!(strlen(ep->d_name)>=2 && ishex(ep->d_name[0]) && ishex(ep->d_name[1])))
			continue;
		
		FILE *fp = fopen(ep->d_name, "rb");
		if (fp==NULL) {
			fprintf(stderr, "No se puede abrir el fichero \"%s\"\n", ep->d_name);
			continue;
		}
		
		fread(buffer, 1, 8, fp);
		if (png_sig_cmp(buffer, 0, 8)) {
			fprintf(stderr, "El fichero \"%s\" no es PNG\n", ep->d_name);
			continue;
		}
		
		generarbitmap(fp, ep->d_name);
		
		fclose(fp);
	}
	printf("Tamaño final: %d bytes\n", tam);
	closedir (dp);

	return 0;

}

